Req
Latest version of firefox or 45+
(https://support.mozilla.org/en-US/kb/find-what-version-firefox-you-are-using)

Steps To Install:
1. Open firefox
2. Drag and drop cognizantits.xpi into firefox
3. click Add/Ok
Thats it!!